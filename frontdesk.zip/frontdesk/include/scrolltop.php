<div class="scroll-top-wrapper ">
    <span class="scroll-top-inner">
        <i class="fa fa-1x fa-chevron-up"></i>
    </span>
</div>