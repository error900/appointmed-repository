<?php
$search = $_POST['search'];
header("location: searchpage.php?q=".$search);

?>