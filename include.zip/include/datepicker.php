<script type="text/javascript" src="js/moment.js"></script>
<script type="text/javascript" src="js/bootstrap-datetimepicker.min.js"></script>

<script type="text/javascript">
    $(function() {
        $('#datetimepicker1').datetimepicker();
        format: 'dd-mm-yyyy'
    });
</script>