<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $title ?></title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <link href="css/bootstrap-datetimepicker.min.css" rel="stylesheet">

    <link href="css/styles.css" rel="stylesheet">
    <link href="css/search.css" rel="stylesheet">
    <link href="css/tooltip.css" rel="stylesheet">
    <link href="css/scrolltop.css" rel="stylesheet">
    <link rel="shortcut icon" href="img/favicon.ico">
</head>